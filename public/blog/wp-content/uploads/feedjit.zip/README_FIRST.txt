This Wordpress plugin has been created specifically for you.
Please don't redistribute it. If you would like your friends to run Feedjit, 
suggest that they also visit http://feedjit.com/ to get their own plugin.

To install this plugin:

1. Copy the feedjit.php file into wp-content/plugins folder on your blog. 

2. Activate the plugin by going to your blog's Plugin tab and clicking Activate.

3. Then go to the Appearance/Widgets menu and you'll see Feedjit listed. Drag
   the Feedjit widget to the sidebar on the side to activate it. You'll see
   Feedjit's options appear with the colors and width you selected on our site.
   You can customize the colors or width and when you hit Save the changes
   are immediately active on your blog.

We hope you enjoy Feedjit as much as we do. Please send any comments to support@feedjit.com
or use the contact form on our site.

Regards,

The Feedjit Team.

